package com.example.student;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private TimePicker mTimePicker;
    private String time, com;
    private EditText number;
    private Button register,student,call;
    private DatabaseReference mDatabase;
    SharedPreferences sharedpreferences;
    String MyPREFERENCES = "MyPrefs";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        number = findViewById(R.id.number);
        mTimePicker = findViewById(R.id.TimeC);
       student=findViewById(R.id.student);
        register = findViewById(R.id.register);
        call=findViewById(R.id.call);
        mDatabase = FirebaseDatabase.getInstance().getReference();


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String num=number.getText().toString();
                int hr = mTimePicker.getCurrentHour();
                int min = mTimePicker.getCurrentMinute();

                if (min < 10) {
                    time = hr + ":0" + min;
                } else {
                    time = hr + ":" + min;
                }
                ad info = new ad();
                info.setNumber(num);
                info.setTime(time);
                mDatabase.setValue(info).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            final AlertDialog.Builder a1 = new AlertDialog.Builder(MainActivity.this);
                            a1.setTitle("set");
                            a1.setMessage("no of student: " + num+ "\n" + "Time slot " + time);

                            a1.setPositiveButton("Ok", null);


                            a1.show();


                        }
                    }
                });

            }
        });
        student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, studentActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });







    }

}





