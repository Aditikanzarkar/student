package com.example.student;

import android.widget.EditText;

public class ad {
    private String number;
    private String time;
    private String name;
    private String section;
     public ad(){}

    public String getNumber() {
        return number;
    }

    public String getTime() {
        return time;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }
}
